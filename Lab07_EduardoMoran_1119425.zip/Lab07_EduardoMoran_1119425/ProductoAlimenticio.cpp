#include "pch.h"
#include "ProductoAlimenticio.h"
#include <iostream>

// Constructor
ProductoAlimenticio::ProductoAlimenticio(const string& nombre, double precio, int id, const string& fechaCaducidad, double peso)
    : Producto(nombre, precio, id), fechaCaducidad(fechaCaducidad), peso(peso) {
}

// Destructor
ProductoAlimenticio::~ProductoAlimenticio() {
}

// Implementaci�n del m�todo virtual puro
void ProductoAlimenticio::mostrarInfo() const {
    cout << "=== PRODUCTO ALIMENTICIO ===" << endl;
    cout << "ID: " << id << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Precio: $" << precio << endl;
    cout << "Fecha de Caducidad: " << fechaCaducidad << endl;
    cout << "Peso: " << peso << " kg" << endl;
    cout << "============================" << endl;
}

// Getters espec�ficos
string ProductoAlimenticio::getFechaCaducidad() const {
    return fechaCaducidad;
}

double ProductoAlimenticio::getPeso() const {
    return peso;
}

// Setters espec�ficos
void ProductoAlimenticio::setFechaCaducidad(const string& nuevaFecha) {
    fechaCaducidad = nuevaFecha;
}

void ProductoAlimenticio::setPeso(double nuevoPeso) {
    peso = nuevoPeso;
}

