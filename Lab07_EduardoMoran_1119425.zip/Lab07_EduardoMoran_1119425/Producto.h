#ifndef PRODUCTO_H
#define PRODUCTO_H

#include <string>
using namespace std;

// Clase abstracta base
class Producto {
protected:
    string nombre;
    double precio;
    int id;

public:
    // Constructor
    Producto(const string& nombre, double precio, int id);

    // Destructor virtual
    virtual ~Producto();

    // M�todo virtual puro
    virtual void mostrarInfo() const = 0;

    // Getters
    string getNombre() const;
    double getPrecio() const;
    int getId() const;

    // Setters
    void setPrecio(double nuevoPrecio);
    void setNombre(const string& nuevoNombre);
};

#endif
