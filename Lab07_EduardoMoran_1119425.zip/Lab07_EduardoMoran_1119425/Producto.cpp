#include "pch.h"
#include "Producto.h"

// Constructor
Producto::Producto(const string& nombre, double precio, int id)
    : nombre(nombre), precio(precio), id(id) {
}

// Destructor
Producto::~Producto() {
}

// Getters
string Producto::getNombre() const {
    return nombre;
}

double Producto::getPrecio() const {
    return precio;
}

int Producto::getId() const {
    return id;
}

// Setters
void Producto::setPrecio(double nuevoPrecio) {
    precio = nuevoPrecio;
}

void Producto::setNombre(const string& nuevoNombre) {
    nombre = nuevoNombre;
}