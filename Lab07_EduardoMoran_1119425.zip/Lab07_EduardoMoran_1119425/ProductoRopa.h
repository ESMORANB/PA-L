#ifndef PRODUCTO_ROPA_H
#define PRODUCTO_ROPA_H

#include "Producto.h"

class ProductoRopa : public Producto {
private:
    string talla;
    string material;

public:
    // Constructor
    ProductoRopa(const string& nombre, double precio, int id, const string& talla, const string& material);

    // Destructor
    ~ProductoRopa();

    // Implementaci�n del m�todo virtual puro
    void mostrarInfo() const override;

    // Getters espec�ficos
    string getTalla() const;
    string getMaterial() const;

    // Setters espec�ficos
    void setTalla(const string& nuevaTalla);
    void setMaterial(const string& nuevoMaterial);
};

#endif
