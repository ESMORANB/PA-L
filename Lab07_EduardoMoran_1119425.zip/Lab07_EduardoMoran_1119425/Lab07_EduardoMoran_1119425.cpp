#include "pch.h"
#include <iostream>
#include <string>
#include "Inventario.h"

using namespace std;

void mostrarMenu() {
    cout << "\n=== SISTEMA DE INVENTARIO ===" << endl;
    cout << "1. Agregar producto" << endl;
    cout << "2. Eliminar producto" << endl;
    cout << "3. Buscar producto" << endl;
    cout << "4. Reportes" << endl;
    cout << "5. Actualizar precio" << endl;
    cout << "6. Ordenar productos" << endl;
    cout << "7. Filtrar productos" << endl;
    cout << "8. Ver estad�sticas" << endl;
    cout << "9. Salir" << endl;
    cout << "Seleccione una opci�n: ";
}

void mostrarMenuReportes() {
    cout << "\n=== REPORTES ===" << endl;
    cout << "0. Mostrar todos los productos" << endl;
    cout << "1. Calcular valor total del inventario" << endl;
    cout << "2. Contar productos por tipo" << endl;
    cout << "3. Mostrar productos pr�ximos a caducar" << endl;
    cout << "4. Mostrar productos con precio mayor a un valor" << endl;
    cout << "Seleccione un reporte: ";
}

void mostrarMenuActualizarPrecio() {
    cout << "\n=== ACTUALIZAR PRECIO ===" << endl;
    cout << "0. Aumentar precio (porcentaje)" << endl;
    cout << "1. Disminuir precio (porcentaje)" << endl;
    cout << "2. Cambiar precio fijo" << endl;
    cout << "Seleccione tipo de actualizaci�n: ";
}

void mostrarMenuOrdenar() {
    cout << "\n=== ORDENAR PRODUCTOS ===" << endl;
    cout << "1. Ordenar por precio (ascendente)" << endl;
    cout << "2. Ordenar por precio (descendente)" << endl;
    cout << "3. Ordenar por nombre (alfab�ticamente)" << endl;
    cout << "4. Ordenar por fecha de caducidad (solo alimenticios)" << endl;
    cout << "Seleccione opci�n: ";
}

void mostrarMenuFiltrar() {
    cout << "\n=== FILTRAR PRODUCTOS ===" << endl;
    cout << "1. Por rango de precios" << endl;
    cout << "2. Por tipo de producto" << endl;
    cout << "Seleccione opci�n: ";
}

void agregarProducto(Inventario& inventario) {
    int tipo, id;
    string nombre;
    double precio;

    cout << "\nTipo de producto:" << endl;
    cout << "1. Electr�nico" << endl;
    cout << "2. Alimenticio" << endl;
    cout << "3. Ropa" << endl;
    cout << "Seleccione: ";
    cin >> tipo;

    cout << "ID del producto: ";
    cin >> id;
    cin.ignore(); // Limpiar buffer

    cout << "Nombre del producto: ";
    getline(cin, nombre);

    cout << "Precio: $";
    cin >> precio;

    Producto* producto = nullptr;

    switch (tipo) {
    case 1: {
        int garantia, voltaje;
        cout << "Garant�a (meses): ";
        cin >> garantia;
        cout << "Voltaje: ";
        cin >> voltaje;
        producto = new ProductoElectronico(nombre, precio, id, garantia, voltaje);
        break;
    }
    case 2: {
        string fechaCaducidad;
        double peso;
        cin.ignore(); // Limpiar buffer
        cout << "Fecha de caducidad (dd/mm/yyyy): ";
        getline(cin, fechaCaducidad);
        cout << "Peso (kg): ";
        cin >> peso;
        producto = new ProductoAlimenticio(nombre, precio, id, fechaCaducidad, peso);
        break;
    }
    case 3: {
        string talla, material;
        cin.ignore(); // Limpiar buffer
        cout << "Talla: ";
        getline(cin, talla);
        cout << "Material: ";
        getline(cin, material);
        producto = new ProductoRopa(nombre, precio, id, talla, material);
        break;
    }
    default:
        cout << "Tipo de producto no v�lido." << endl;
        return;
    }

    if (producto != nullptr) {
        inventario.agregarProducto(producto);
    }
}

int main() {
    Inventario inventario;
    int opcion;

    cout << "Bienvenido al Sistema de Gesti�n de Inventario" << endl;

    do {
        mostrarMenu();
        cin >> opcion;

        switch (opcion) {
        case 1: {
            agregarProducto(inventario);
            break;
        }
        case 2: {
            int id;
            cout << "ID del producto a eliminar: ";
            cin >> id;
            inventario.eliminarProducto(id);
            break;
        }
        case 3: {
            int id;
            cout << "ID del producto a buscar: ";
            cin >> id;
            Producto* producto = inventario.buscarProducto(id);
            if (producto != nullptr) {
                cout << "\nProducto encontrado:" << endl;
                producto->mostrarInfo();
            }
            else {
                cout << "Producto no encontrado." << endl;
            }
            break;
        }
        case 4: {
            int reporte;
            mostrarMenuReportes();
            cin >> reporte;
            inventario.ejecutarReporte(reporte);
            break;
        }
        case 5: {
            int id, tipoActualizacion;
            double valor;
            cout << "ID del producto: ";
            cin >> id;
            mostrarMenuActualizarPrecio();
            cin >> tipoActualizacion;
            cout << "Valor (porcentaje o precio fijo): ";
            cin >> valor;
            inventario.ejecutarActualizacionPrecio(id, tipoActualizacion, valor);
            break;
        }
        case 6: {
            int opcionOrden;
            mostrarMenuOrdenar();
            cin >> opcionOrden;
            switch (opcionOrden) {
            case 1:
                inventario.ordenarPorPrecio(true);
                break;
            case 2:
                inventario.ordenarPorPrecio(false);
                break;
            case 3:
                inventario.ordenarPorNombre();
                break;
            case 4:
                inventario.ordenarPorFechaCaducidad();
                break;
            default:
                cout << "Opci�n no v�lida." << endl;
            }
            break;
        }
        case 7: {
            int opcionFiltro;
            mostrarMenuFiltrar();
            cin >> opcionFiltro;
            switch (opcionFiltro) {
            case 1: {
                double minPrecio, maxPrecio;
                cout << "Precio m�nimo: $";
                cin >> minPrecio;
                cout << "Precio m�ximo: $";
                cin >> maxPrecio;
                inventario.filtrarPorRangoPrecios(minPrecio, maxPrecio);
                break;
            }
            case 2: {
                int tipoProducto;
                cout << "\nTipo de producto:" << endl;
                cout << "1. Electr�nico" << endl;
                cout << "2. Alimenticio" << endl;
                cout << "3. Ropa" << endl;
                cout << "Seleccione: ";
                cin >> tipoProducto;
                inventario.filtrarPorTipo(tipoProducto);
                break;
            }
            default:
                cout << "Opci�n no v�lida." << endl;
            }
            break;
        }
        case 8: {
            inventario.mostrarEstadisticas();
            break;
        }
        case 9: {
            cout << "Saliendo del sistema..." << endl;
            break;
        }
        default: {
            cout << "Opci�n no v�lida. Intente nuevamente." << endl;
            break;
        }
        }

        if (opcion != 9) {
            cout << "\nPresione Enter para continuar...";
            cin.ignore();
            cin.get();
        }

    } while (opcion != 9);

    return 0;
}
