#include "pch.h"
#include "ProductoElectronico.h"
#include <iostream>

// Constructor
ProductoElectronico::ProductoElectronico(const string& nombre, double precio, int id, int garantia, int voltaje)
    : Producto(nombre, precio, id), garantia(garantia), voltaje(voltaje) {
}

// Destructor
ProductoElectronico::~ProductoElectronico() {
}

// Implementaci�n del m�todo virtual puro
void ProductoElectronico::mostrarInfo() const {
    std::cout << "=== PRODUCTO ELECTRONICO ===" << std::endl;
    std::cout << "ID: " << id << std::endl;
    std::cout << "Nombre: " << nombre << std::endl;
    std::cout << "Precio: $" << precio << std::endl;
    std::cout << "Garant�a: " << garantia << " meses" << std::endl;
    std::cout << "Voltaje: " << voltaje << " V" << std::endl;
    std::cout << "============================" << std::endl;
}

// Getters espec�ficos
int ProductoElectronico::getGarantia() const {
    return garantia;
}

int ProductoElectronico::getVoltaje() const {
    return voltaje;
}

// Setters espec�ficos
void ProductoElectronico::setGarantia(int nuevaGarantia) {
    garantia = nuevaGarantia;
}

void ProductoElectronico::setVoltaje(int nuevoVoltaje) {
    voltaje = nuevoVoltaje;
}