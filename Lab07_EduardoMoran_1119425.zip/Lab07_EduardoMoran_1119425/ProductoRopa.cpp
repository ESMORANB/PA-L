#include "pch.h"
#include "ProductoRopa.h"
#include <iostream>

// Constructor
ProductoRopa::ProductoRopa(const string& nombre, double precio, int id, const string& talla, const string& material)
    : Producto(nombre, precio, id), talla(talla), material(material) {
}

// Destructor
ProductoRopa::~ProductoRopa() {
}

// Implementaci�n del m�todo virtual puro
void ProductoRopa::mostrarInfo() const {
    cout << "=== PRODUCTO DE ROPA ===" << endl;
    cout << "ID: " << id << endl;
    cout << "Nombre: " << nombre << endl;
    cout << "Precio: $" << precio << endl;
    cout << "Talla: " << talla << endl;
    cout << "Material: " << material << endl;
    cout << "========================" << endl;
}

// Getters espec�ficos
string ProductoRopa::getTalla() const {
    return talla;
}

string ProductoRopa::getMaterial() const {
    return material;
}

// Setters espec�ficos
void ProductoRopa::setTalla(const string& nuevaTalla) {
    talla = nuevaTalla;
}

void ProductoRopa::setMaterial(const string& nuevoMaterial) {
    material = nuevoMaterial;
}