#ifndef PRODUCTO_ALIMENTICIO_H
#define PRODUCTO_ALIMENTICIO_H

#include "Producto.h"

class ProductoAlimenticio : public Producto {
private:
    string fechaCaducidad;
    double peso; // en kg

public:
    // Constructor
    ProductoAlimenticio(const string& nombre, double precio, int id, const string& fechaCaducidad, double peso);

    // Destructor
    ~ProductoAlimenticio();

    // Implementaci�n del m�todo virtual puro
    void mostrarInfo() const override;

    // Getters espec�ficos
    string getFechaCaducidad() const;
    double getPeso() const;

    // Setters espec�ficos
    void setFechaCaducidad(const string& nuevaFecha);
    void setPeso(double nuevoPeso);
};

#endif