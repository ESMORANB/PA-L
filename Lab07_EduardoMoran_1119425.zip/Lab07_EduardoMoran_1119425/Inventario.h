#ifndef INVENTARIO_H
#define INVENTARIO_H

#include "Producto.h"
#include "ProductoElectronico.h"
#include "ProductoAlimenticio.h"
#include "ProductoRopa.h"

class Inventario {
private:
    Producto** productos;  // Array din�mico de punteros a Producto
    int capacidad;
    int cantidad;

    // Funciones para reportes
    static void mostrarTodosProductos(Inventario* inv);
    static void calcularValorTotal(Inventario* inv);
    static void contarProductosPorTipo(Inventario* inv);
    static void mostrarProductosProximosCaducar(Inventario* inv);
    static void mostrarProductosPrecioMayor(Inventario* inv);

    // Funciones para actualizar precios
    static void aumentarPrecio(Producto* prod, double porcentaje);
    static void disminuirPrecio(Producto* prod, double porcentaje);
    static void cambiarPrecioFijo(Producto* prod, double nuevoPrecio);

public:
    // Array de punteros a funciones para reportes
    static void (*reportes[5])(Inventario*);

    // Array de punteros a funciones para actualizar precios
    static void (*actualizarPrecios[3])(Producto*, double);

    // Constructor
    Inventario(int capacidadInicial = 10);

    // Destructor
    ~Inventario();

    // Gesti�n de productos
    void agregarProducto(Producto* producto);
    bool eliminarProducto(int id);
    Producto* buscarProducto(int id);

    // Reportes usando punteros a funciones
    void ejecutarReporte(int indiceReporte);
    void ejecutarActualizacionPrecio(int id, int tipoActualizacion, double valor);

    // Ordenamiento
    void ordenarPorPrecio(bool ascendente = true);
    void ordenarPorNombre();
    void ordenarPorFechaCaducidad();

    // Filtros
    void filtrarPorRangoPrecios(double minPrecio, double maxPrecio);
    void filtrarPorTipo(int tipoProducto); // 1=Electronico, 2=Alimenticio, 3=Ropa

    // Estad�sticas
    void mostrarEstadisticas();

    // Getters
    int getCantidad() const;
    int getCapacidad() const;
    Producto** getProductos() const;
};

#endif

