#include "pch.h"
#include "Inventario.h"
#include <iostream>
#include <algorithm>
#include <cstring>

// Inicializaci�n de arrays est�ticos de punteros a funciones
void (*Inventario::reportes[5])(Inventario*) = {
    mostrarTodosProductos,
    calcularValorTotal,
    contarProductosPorTipo,
    mostrarProductosProximosCaducar,
    mostrarProductosPrecioMayor
};

void (*Inventario::actualizarPrecios[3])(Producto*, double) = {
    aumentarPrecio,
    disminuirPrecio,
    cambiarPrecioFijo
};

// Constructor
Inventario::Inventario(int capacidadInicial) {
    capacidad = capacidadInicial;
    cantidad = 0;
    productos = new Producto * [capacidad];
    for (int i = 0; i < capacidad; i++) {
        productos[i] = nullptr;
    }
}

// Destructor
Inventario::~Inventario() {
    for (int i = 0; i < cantidad; i++) {
        delete productos[i];
    }
    delete[] productos;
}

// Agregar producto
void Inventario::agregarProducto(Producto* producto) {
    if (cantidad >= capacidad) {
        // Expandir array
        capacidad *= 2;
        Producto** nuevoArray = new Producto * [capacidad];
        for (int i = 0; i < cantidad; i++) {
            nuevoArray[i] = productos[i];
        }
        for (int i = cantidad; i < capacidad; i++) {
            nuevoArray[i] = nullptr;
        }
        delete[] productos;
        productos = nuevoArray;
    }
    productos[cantidad++] = producto;
    cout << "Producto agregado exitosamente." << endl;
}

// Eliminar producto por ID
bool Inventario::eliminarProducto(int id) {
    for (int i = 0; i < cantidad; i++) {
        if (productos[i]->getId() == id) {
            delete productos[i];
            // Mover elementos hacia atr�s
            for (int j = i; j < cantidad - 1; j++) {
                productos[j] = productos[j + 1];
            }
            productos[--cantidad] = nullptr;
            cout << "Producto eliminado exitosamente." << endl;
            return true;
        }
    }
    cout << "Producto no encontrado." << endl;
    return false;
}

// Buscar producto por ID
Producto* Inventario::buscarProducto(int id) {
    for (int i = 0; i < cantidad; i++) {
        if (productos[i]->getId() == id) {
            return productos[i];
        }
    }
    return nullptr;
}

// Ejecutar reporte usando array de punteros a funciones
void Inventario::ejecutarReporte(int indiceReporte) {
    if (indiceReporte >= 0 && indiceReporte < 5) {
        reportes[indiceReporte](this);
    }
    else {
        cout << "Reporte no v�lido." << endl;
    }
}

// Ejecutar actualizaci�n de precio usando punteros a funciones
void Inventario::ejecutarActualizacionPrecio(int id, int tipoActualizacion, double valor) {
    Producto* prod = buscarProducto(id);
    if (prod != nullptr && tipoActualizacion >= 0 && tipoActualizacion < 3) {
        actualizarPrecios[tipoActualizacion](prod, valor);
        cout << "Precio actualizado exitosamente." << endl;
    }
    else {
        cout << "Producto no encontrado o tipo de actualizaci�n no v�lido." << endl;
    }
}

// Funciones est�ticas para reportes
void Inventario::mostrarTodosProductos(Inventario* inv) {
    cout << "\n=== TODOS LOS PRODUCTOS ===" << endl;
    if (inv->cantidad == 0) {
        cout << "No hay productos en el inventario." << endl;
        return;
    }
    for (int i = 0; i < inv->cantidad; i++) {
        inv->productos[i]->mostrarInfo();
        cout << endl;
    }
}

void Inventario::calcularValorTotal(Inventario* inv) {
    double total = 0.0;
    for (int i = 0; i < inv->cantidad; i++) {
        total += inv->productos[i]->getPrecio();
    }
    cout << "\nValor total del inventario: $" << total << endl;
}

void Inventario::contarProductosPorTipo(Inventario* inv) {
    int electronicos = 0, alimenticios = 0, ropa = 0;

    for (int i = 0; i < inv->cantidad; i++) {
        if (dynamic_cast<ProductoElectronico*>(inv->productos[i])) {
            electronicos++;
        }
        else if (dynamic_cast<ProductoAlimenticio*>(inv->productos[i])) {
            alimenticios++;
        }
        else if (dynamic_cast<ProductoRopa*>(inv->productos[i])) {
            ropa++;
        }
    }

    cout << "\n=== CONTEO POR TIPO ===" << endl;
    cout << "Productos Electr�nicos: " << electronicos << endl;
    cout << "Productos Alimenticios: " << alimenticios << endl;
    cout << "Productos de Ropa: " << ropa << endl;
}

void Inventario::mostrarProductosProximosCaducar(Inventario* inv) {
    cout << "\n=== PRODUCTOS PR�XIMOS A CADUCAR ===" << endl;
    bool encontrados = false;

    for (int i = 0; i < inv->cantidad; i++) {
        ProductoAlimenticio* prodAlim = dynamic_cast<ProductoAlimenticio*>(inv->productos[i]);
        if (prodAlim) {
            // Mostrar todos los productos alimenticios con su fecha
            prodAlim->mostrarInfo();
            encontrados = true;
        }
    }

    if (!encontrados) {
        cout << "No hay productos alimenticios en el inventario." << endl;
    }
}

void Inventario::mostrarProductosPrecioMayor(Inventario* inv) {
    double valorLimite;
    cout << "Ingrese el valor l�mite: ";
    cin >> valorLimite;

    cout << "\n=== PRODUCTOS CON PRECIO MAYOR A $" << valorLimite << " ===" << endl;
    bool encontrados = false;

    for (int i = 0; i < inv->cantidad; i++) {
        if (inv->productos[i]->getPrecio() > valorLimite) {
            inv->productos[i]->mostrarInfo();
            encontrados = true;
        }
    }

    if (!encontrados) {
        cout << "No hay productos con precio mayor al valor especificado." << endl;
    }
}

// Funciones est�ticas para actualizar precios
void Inventario::aumentarPrecio(Producto* prod, double porcentaje) {
    double nuevoPrecio = prod->getPrecio() * (1.0 + porcentaje / 100.0);
    prod->setPrecio(nuevoPrecio);
}

void Inventario::disminuirPrecio(Producto* prod, double porcentaje) {
    double nuevoPrecio = prod->getPrecio() * (1.0 - porcentaje / 100.0);
    if (nuevoPrecio < 0) nuevoPrecio = 0;
    prod->setPrecio(nuevoPrecio);
}

void Inventario::cambiarPrecioFijo(Producto* prod, double nuevoPrecio) {
    prod->setPrecio(nuevoPrecio);
}

// Ordenar por precio
void Inventario::ordenarPorPrecio(bool ascendente) {
    for (int i = 0; i < cantidad - 1; i++) {
        for (int j = 0; j < cantidad - i - 1; j++) {
            bool intercambiar = ascendente ?
                productos[j]->getPrecio() > productos[j + 1]->getPrecio() :
                productos[j]->getPrecio() < productos[j + 1]->getPrecio();

            if (intercambiar) {
                Producto* temp = productos[j];
                productos[j] = productos[j + 1];
                productos[j + 1] = temp;
            }
        }
    }
    cout << "Productos ordenados por precio " << (ascendente ? "ascendente" : "descendente") << "." << endl;
}

// Ordenar por nombre
void Inventario::ordenarPorNombre() {
    for (int i = 0; i < cantidad - 1; i++) {
        for (int j = 0; j < cantidad - i - 1; j++) {
            if (productos[j]->getNombre() > productos[j + 1]->getNombre()) {
                Producto* temp = productos[j];
                productos[j] = productos[j + 1];
                productos[j + 1] = temp;
            }
        }
    }
    cout << "Productos ordenados por nombre alfab�ticamente." << endl;
}

// Ordenar por fecha de caducidad
void Inventario::ordenarPorFechaCaducidad() {
    // Crear array temporal solo con productos alimenticios
    ProductoAlimenticio** alimenticios = new ProductoAlimenticio * [cantidad];
    int contAlim = 0;

    for (int i = 0; i < cantidad; i++) {
        ProductoAlimenticio* prodAlim = dynamic_cast<ProductoAlimenticio*>(productos[i]);
        if (prodAlim) {
            alimenticios[contAlim++] = prodAlim;
        }
    }

    // Ordenar productos alimenticios por fecha
    for (int i = 0; i < contAlim - 1; i++) {
        for (int j = 0; j < contAlim - i - 1; j++) {
            if (alimenticios[j]->getFechaCaducidad() > alimenticios[j + 1]->getFechaCaducidad()) {
                ProductoAlimenticio* temp = alimenticios[j];
                alimenticios[j] = alimenticios[j + 1];
                alimenticios[j + 1] = temp;
            }
        }
    }

    cout << "Productos alimenticios ordenados por fecha de caducidad:" << endl;
    for (int i = 0; i < contAlim; i++) {
        alimenticios[i]->mostrarInfo();
    }

    delete[] alimenticios;
}

// Filtrar por rango de precios
void Inventario::filtrarPorRangoPrecios(double minPrecio, double maxPrecio) {
    cout << "\n=== PRODUCTOS EN RANGO $" << minPrecio << " - $" << maxPrecio << " ===" << endl;
    bool encontrados = false;

    for (int i = 0; i < cantidad; i++) {
        double precio = productos[i]->getPrecio();
        if (precio >= minPrecio && precio <= maxPrecio) {
            productos[i]->mostrarInfo();
            encontrados = true;
        }
    }

    if (!encontrados) {
        cout << "No hay productos en el rango de precios especificado." << endl;
    }
}

// Filtrar por tipo de producto
void Inventario::filtrarPorTipo(int tipoProducto) {
    string tipoNombre;
    bool encontrados = false;

    switch (tipoProducto) {
    case 1:
        tipoNombre = "ELECTR�NICOS";
        cout << "\n=== PRODUCTOS " << tipoNombre << " ===" << endl;
        for (int i = 0; i < cantidad; i++) {
            if (dynamic_cast<ProductoElectronico*>(productos[i])) {
                productos[i]->mostrarInfo();
                encontrados = true;
            }
        }
        break;
    case 2:
        tipoNombre = "ALIMENTICIOS";
        cout << "\n=== PRODUCTOS " << tipoNombre << " ===" << endl;
        for (int i = 0; i < cantidad; i++) {
            if (dynamic_cast<ProductoAlimenticio*>(productos[i])) {
                productos[i]->mostrarInfo();
                encontrados = true;
            }
        }
        break;
    case 3:
        tipoNombre = "DE ROPA";
        cout << "\n=== PRODUCTOS " << tipoNombre << " ===" << endl;
        for (int i = 0; i < cantidad; i++) {
            if (dynamic_cast<ProductoRopa*>(productos[i])) {
                productos[i]->mostrarInfo();
                encontrados = true;
            }
        }
        break;
    default:
        cout << "Tipo de producto no v�lido." << endl;
        return;
    }

    if (!encontrados) {
        cout << "No hay productos del tipo especificado." << endl;
    }
}

// Mostrar estad�sticas
void Inventario::mostrarEstadisticas() {
    if (cantidad == 0) {
        cout << "No hay productos para mostrar estad�sticas." << endl;
        return;
    }

    cout << "\n=== ESTAD�STICAS DEL INVENTARIO ===" << endl;

    // Precio promedio
    double sumaPrecios = 0.0;
    for (int i = 0; i < cantidad; i++) {
        sumaPrecios += productos[i]->getPrecio();
    }
    cout << "Precio promedio: $" << (sumaPrecios / cantidad) << endl;

    // Producto m�s caro y m�s barato
    Producto* masCaro = productos[0];
    Producto* masBarato = productos[0];

    for (int i = 1; i < cantidad; i++) {
        if (productos[i]->getPrecio() > masCaro->getPrecio()) {
            masCaro = productos[i];
        }
        if (productos[i]->getPrecio() < masBarato->getPrecio()) {
            masBarato = productos[i];
        }
    }

    cout << "\nProducto m�s caro: " << masCaro->getNombre()
        << " ($" << masCaro->getPrecio() << ")" << endl;
    cout << "Producto m�s barato: " << masBarato->getNombre()
        << " ($" << masBarato->getPrecio() << ")" << endl;

    // Peso total de productos alimenticios
    double pesoTotal = 0.0;
    for (int i = 0; i < cantidad; i++) {
        ProductoAlimenticio* prodAlim = dynamic_cast<ProductoAlimenticio*>(productos[i]);
        if (prodAlim) {
            pesoTotal += prodAlim->getPeso();
        }
    }
    cout << "Peso total de productos alimenticios: " << pesoTotal << " kg" << endl;

    // Valor total de electr�nicos en garant�a (asumimos que todos est�n en garant�a)
    double valorElectronicos = 0.0;
    for (int i = 0; i < cantidad; i++) {
        ProductoElectronico* prodElec = dynamic_cast<ProductoElectronico*>(productos[i]);
        if (prodElec && prodElec->getGarantia() > 0) {
            valorElectronicos += prodElec->getPrecio();
        }
    }
    cout << "Valor total de electr�nicos en garant�a: $" << valorElectronicos << endl;
}

// Getters
int Inventario::getCantidad() const {
    return cantidad;
}

int Inventario::getCapacidad() const {
    return capacidad;
}

Producto** Inventario::getProductos() const {
    return productos;
}