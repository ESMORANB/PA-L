#ifndef PRODUCTO_ELECTRONICO_H
#define PRODUCTO_ELECTRONICO_H

#include "Producto.h"

class ProductoElectronico : public Producto {
private:
    int garantia; // en meses
    int voltaje;

public:
    // Constructor
    ProductoElectronico(const string& nombre, double precio, int id, int garantia, int voltaje);

    // Destructor
    ~ProductoElectronico();

    // Implementaci�n del m�todo virtual puro
    void mostrarInfo() const override;

    // Getters espec�ficos
    int getGarantia() const;
    int getVoltaje() const;

    // Setters espec�ficos
    void setGarantia(int nuevaGarantia);
    void setVoltaje(int nuevoVoltaje);
};

#endif

